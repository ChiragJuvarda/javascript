import { initializeApp } from "firebase/app";
import { getAuth } from 'firebase/auth'
// Import the functions you need from the SDKs you need

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC5D3ej6viO0O7-arJv5G5zRxx53Az904U",
  authDomain: "userauth-1dcae.firebaseapp.com",
  projectId: "userauth-1dcae",
  storageBucket: "userauth-1dcae.firebasestorage.app",
  messagingSenderId: "837306508716",
  appId: "1:837306508716:web:136997524ff571376a4609",
  measurementId: "G-JSHP8ZE7F0"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app)
export { auth }