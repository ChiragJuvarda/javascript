import React from 'react'

function Colorlib() {
  return (
    <div className='Colorlib'>
        <img src='https://lithoreact.themezaa.com/assets/img/webp/company-logo-02.webp' />
        <img src='https://lithoreact.themezaa.com/assets/img/webp/company-logo-05.webp' />
        <img src='https://lithoreact.themezaa.com/assets/img/webp/company-logo-06.webp' />
        <img src='https://lithoreact.themezaa.com/assets/img/webp/company-logo-03.webp' />
    </div>
  )
}

export default Colorlib